def main():
    print("Hello from flask-test-app!")


if __name__ == "__main__":
    main()
